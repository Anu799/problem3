package com.example.demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class SupplyService {
    public List<Supply> getSupply() throws ParseException {
        List<Supply> supplies = new ArrayList<>();
        supplies.add(new Supply("Product1",new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse("2021-03-16 08:53:48.616"),10.0));
        supplies.add(new Supply("Product2",new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse("2021-03-16 08:59:48.616"),5.0));
        supplies.add(new Supply("Product3",new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse("2021-03-16 09:10:48.616"),30.0));
        supplies.add(new Supply("Product4",new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse("2021-03-16 09:10:48.616"),20.0));
        return supplies;
    }
    public Supply updateSupply(Supply supply) {

        try {
            getSupply().stream().forEach(supply1 -> {
                if (supply1.getProductId().equals(supply.getProductId())) {
                    if (supply.getUpdateTimeStamp().compareTo(supply1.getUpdateTimeStamp()) > 0) {
                        supply.setStatus("Updated");
                        supply.setQuantity(supply.getQuantity() + supply1.getQuantity());
                    } else {
                        supply.setStatus("Out Of Sync Update");
                    }
                }
            });
        }catch (ParseException p){
            p.getMessage();
        }
        return supply;
    }
}
